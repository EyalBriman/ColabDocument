# Configs
configurations = [
    {"sparsity": 0.3, "num_agents": 20, "num_paragraphs": 20, "file_path": "...", "instance_id": "instance_0"},
    {"sparsity": 0.7, "num_agents": 20, "num_paragraphs": 20, "file_path": "...", "instance_id": "instance_1"},
    {"sparsity": 0.3, "num_agents": 40, "num_paragraphs": 20, "file_path": "...", "instance_id": "instance_2"},
    {"sparsity": 0.7, "num_agents": 40, "num_paragraphs": 20, "file_path": "...", "instance_id": "instance_3"}
]