"""
A script to load a trained model and run it in the environment for some episodes, collecting evaluation metrics.
"""