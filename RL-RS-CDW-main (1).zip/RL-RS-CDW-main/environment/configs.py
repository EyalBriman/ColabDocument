"""
Defines configuration for the environment (number of agents, number of paragraphs and more).
This file separates constants and tunable parameters from code.
"""
NUM_COLLABORATORS = 20